import { ProgramItem } from '../types';
import { LOCAL_IMAGES } from '../assets/photos';

export const EVENT_DETAILS = {
  familyNames: "Gypsy & Grégoire",
  eventTitle: "UNE CÉLÉBRATION COMMUNE RÉUNISSANT TROIS BEAUX ÉVÉNEMENTS",
  tagline: "UNE CÉLÉBRATION COMMUNE RÉUNISSANT TROIS BEAUX ÉVÉNEMENTS",
  subTagline: "Trois moments d'exception réunis en une seule grande fête d'amour et de gratitude.",
  eventDate: "Samedi 28 Novembre 2026",
  eventIsoDate: "2026-11-28T17:00:00",
  churchName: "Église Saint-Luc de Yénadjro",
  churchAddress: "Yénadjro, Womey",
  churchMapUrl: "https://maps.app.goo.gl/8j1Vub3s1qmb5gku6",
  churchTime: "17:00 précises",
  venueName: "True Paradise",
  venueAddress: "En quittant le Stade de l’Amitié en direction du cimetière PK14, prenez la voie située en face de la station Ewell, juste après le cimetière.",
  venueMapUrl: "https://www.google.com/maps/place/True+Paradise+B%C3%A9nin+%C3%89v%C3%A9nement/@6.3856265,2.3260419,17z/data=!3m1!4b1!4m6!3m5!1s0x102357daf4aa1251:0xda31c08512bd7f65!8m2!3d6.3856265!4d2.3260419!16s%2Fg%2F11fl415pfg!18m1!1e1?entry=ttu&g_ep=EgoyMDI2MDkwMi4wIKXMDSoASAFQAw%3D%3D",
  venueTime: "Dès 18:45 (Cocktail, Dîner & Festivités)",
  dressCode: "Blanc et Chic (Tenue de Célébration & Élégance Blanche)",
  contactEmail: "contact@famille-gypsy-gregoire.com",
  music: {
    youtubeId: "Q4vjJd-LaNo",
    youtubeUrl: "https://youtu.be/Q4vjJd-LaNo?si=AIcCsx_zcirB4Exl",
    title: "Chant d'Adoration & Action de Grâces"
  },
  images: {
    heroBackground: LOCAL_IMAGES.family1,
    heroSecondary: LOCAL_IMAGES.fairePart,
    couple: LOCAL_IMAGES.couple,
    papa: LOCAL_IMAGES.papa1,
    papaSecondary: LOCAL_IMAGES.papa2,
    maman: LOCAL_IMAGES.maman1,
    mamanSecondary: LOCAL_IMAGES.maman2,
    waxSeal: LOCAL_IMAGES.couple,
  }
};

export const FAMILY_GALLERY = [
  {
    name: "Ireti Godson",
    relation: "Fils & Fierté de la Famille",
    image: LOCAL_IMAGES.childIreti
  },
  {
    name: "Jean Rosalie",
    relation: "Famille & Joie Partagée",
    image: LOCAL_IMAGES.childJean
  },
  {
    name: "Marie Claudelle",
    relation: "Fille & Rayon de Soleil",
    image: LOCAL_IMAGES.childMarieClaudelle
  },
  {
    name: "Marie Osange",
    relation: "Fille & Douceur Familiale",
    image: LOCAL_IMAGES.childMarieOsange
  },
  {
    name: "Tobi Marek",
    relation: "Fils & Espoir Familial",
    image: LOCAL_IMAGES.childTobi
  }
];

export const PILLARS_DATA = [
  {
    id: "mariage",
    title: "Noces de Porcelaine",
    subtitle: "Gypsy & Grégoire (20 Ans)",
    quote: "Deux décennies d'amour inconditionnel, de complicité profonde et de bénédictions partagées.",
    highlight: "Noces de Porcelaine",
    bgAccent: "from-[#5A0F1B]/10 to-[#C8A45D]/10",
    badge: "12 Juillet 2006 — 2026",
    details: "Vingt ans d'histoire d'amour à construire main dans la main un foyer empreint de tendresse, de foi et de respect mutuel."
  },
  {
    id: "gypsy",
    title: "Les 50 Ans de Gypsy",
    subtitle: "Jubilé d'Or",
    quote: "Célébrer un demi-siècle de grâce, de beauté intérieure, de bonté et de rayonnement familial.",
    highlight: "50 Ans de Grâce",
    bgAccent: "from-[#C8A45D]/15 to-[#F5EFE4]",
    badge: "Jubilé d'Or",
    details: "Une vie illuminée par la bienveillance, la force maternelle et la joie de vivre entourée des siennes et des siens."
  },
  {
    id: "enfants",
    title: "Notre Héritage & Joie",
    subtitle: "Trésors & Bénédiction",
    quote: "La plus belle réussite de notre union : nos enfants, trésors vivants et source de joie quotidienne.",
    highlight: "La Relève & La Joie",
    bgAccent: "from-[#7A1F2B]/10 to-[#FFFDF8]",
    badge: "Bénédiction Familiale",
    details: "Mettre à l'honneur nos enfants adorés, dont les rires, les projets et la fraîcheur illuminent chaque jour notre maison."
  }
];

export const PROGRAM_SCHEDULE: ProgramItem[] = [
  {
    time: "17:00",
    title: "Messe d'Action de Grâces",
    subtitle: "Bénédictions Solennelles & Hommages",
    description: "Une célébration eucharistique solennelle et émouvante pour rendre grâce à Dieu pour les 20 ans de mariage de Gypsy & Grégoire, le jubilé de Gypsy et les enfants.",
    location: "Église Saint-Luc de Yénadjro",
    iconName: "Church"
  },
  {
    time: "18:45",
    title: "Accueil & Cocktail de Bienvenue",
    subtitle: "Rafraîchissements & Accueil Festif",
    description: "Accueil chaleureux des invités, rafraîchissements, toasts et ouverture officielle des réjouissances.",
    location: "True Paradise",
    iconName: "Wine"
  },
  {
    time: "19:45",
    title: "Banquet & Allocutions d'Honneur",
    subtitle: "Dîner de Fête & Hommages",
    description: "Repas de fête raffiné, témoignages émouvants, allocutions des hôtes et moments de partage fraternel.",
    location: "Grande Salle — True Paradise",
    iconName: "Utensils"
  },
  {
    time: "21:15",
    title: "Le Gâteau des 3 Célébrations",
    subtitle: "Toasts & Découpe Solennelle",
    description: "Découpe solennelle du gâteau d'honneur célébrant le couple, le jubilé de Gypsy et les enfants.",
    iconName: "Cake",
    location: "Espace d'Honneur — True Paradise"
  },
  {
    time: "22:00 - TARD",
    title: "Soirée Dansante & Festivités",
    subtitle: "Animation Musicale & Joie",
    description: "Piste de danse festive et animation musicale pour célébrer dans l'allégresse avec la famille et les amis.",
    iconName: "Music",
    location: "True Paradise"
  }
];
