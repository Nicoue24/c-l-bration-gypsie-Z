import { EVENT_DETAILS } from '../data/eventData';
import { LOCAL_IMAGES } from '../assets/photos';
import luxuryEnvelopeImg from '../assets/images/luxury_tassel_envelope_1787917930376.jpg';
import burgundyCornerImg from '../assets/images/burgundy_floral_corner_1786458580375.jpg';
import burgundyHeaderImg from '../assets/images/burgundy_floral_header_1786442440706.jpg';

const ALL_ASSET_URLS = [
  luxuryEnvelopeImg,
  LOCAL_IMAGES.fairePart,
  LOCAL_IMAGES.family1,
  LOCAL_IMAGES.family2,
  LOCAL_IMAGES.couple,
  LOCAL_IMAGES.papa1,
  LOCAL_IMAGES.papa2,
  LOCAL_IMAGES.maman1,
  LOCAL_IMAGES.maman2,
  LOCAL_IMAGES.childIreti,
  LOCAL_IMAGES.childJean,
  LOCAL_IMAGES.childMarieClaudelle,
  LOCAL_IMAGES.childMarieOsange,
  LOCAL_IMAGES.childTobi,
  burgundyCornerImg,
  burgundyHeaderImg,
];

/**
 * Preloads and decodes images in background for instant, lag-free display
 */
export function preloadAllImages(): void {
  if (typeof window === 'undefined') return;

  const runPreload = () => {
    // 1. High priority first (Envelope & Main Card)
    const critical = [luxuryEnvelopeImg, LOCAL_IMAGES.fairePart];
    critical.forEach((url) => {
      const img = new Image();
      img.decoding = 'async';
      img.src = url;
      if (img.decode) {
        img.decode().catch(() => {});
      }
    });

    // 2. Load all secondary images during idle moments
    const secondary = ALL_ASSET_URLS.filter((u) => !critical.includes(u));
    secondary.forEach((url) => {
      const img = new Image();
      img.decoding = 'async';
      img.src = url;
      if (img.decode) {
        img.decode().catch(() => {});
      }
    });
  };

  if ('requestIdleCallback' in window) {
    (window as unknown as { requestIdleCallback: (cb: () => void) => void }).requestIdleCallback(runPreload);
  } else {
    setTimeout(runPreload, 50);
  }
}
