// Importation locale directe des photos pour un affichage ultra-rapide (0 latence)
import fairePartImg from './faire_part.png';
import family1Img from './family_1.jpg';
import family2Img from './family_2.jpg';
import coupleImg from './couple.jpg';
import papa1Img from './papa_1.jpg';
import papa2Img from './papa_2.jpg';
import maman1Img from './maman_1.jpg';
import maman2Img from './maman_2.jpg';
import childIretiImg from './child_ireti.jpg';
import childJeanImg from './child_jean.jpg';
import childMarieClaudelleImg from './child_marie_claudelle.jpg';
import childMarieOsangeImg from './child_marie_osange.jpg';
import childTobiImg from './child_tobi.jpg';

export const LOCAL_IMAGES = {
  fairePart: fairePartImg,
  family1: family1Img,
  family2: family2Img,
  couple: coupleImg,
  papa1: papa1Img,
  papa2: papa2Img,
  maman1: maman1Img,
  maman2: maman2Img,
  childIreti: childIretiImg,
  childJean: childJeanImg,
  childMarieClaudelle: childMarieClaudelleImg,
  childMarieOsange: childMarieOsangeImg,
  childTobi: childTobiImg,
};
