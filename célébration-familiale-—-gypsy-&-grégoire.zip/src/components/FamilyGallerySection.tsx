import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, Sparkles, Heart, Users, Camera, Maximize2, X } from 'lucide-react';
import { OrnamentalDivider } from './OrnamentalDivider';
import { EVENT_DETAILS } from '../data/eventData';
import { LOCAL_IMAGES } from '../assets/photos';

interface ChildMember {
  id: number;
  name: string;
  image: string;
  objectPosition: string;
  thumbPosition: string;
  role: string;
}

const CHILDREN_DATA: ChildMember[] = [
  {
    id: 1,
    name: "Ireti Godson",
    image: LOCAL_IMAGES.childIreti,
    objectPosition: "50% 4%",
    thumbPosition: "50% 4%",
    role: "Fils & Fierté de la Famille"
  },
  {
    id: 2,
    name: "Jean-Rosalie",
    image: LOCAL_IMAGES.childJean,
    objectPosition: "50% 4%",
    thumbPosition: "50% 4%",
    role: "Famille & Joie Partagée"
  },
  {
    id: 3,
    name: "Marie Claudelle",
    image: LOCAL_IMAGES.childMarieClaudelle,
    objectPosition: "50% 2%",
    thumbPosition: "50% 2%",
    role: "Douceur & Rayonnement"
  },
  {
    id: 4,
    name: "Marie Osange",
    image: LOCAL_IMAGES.childMarieOsange,
    objectPosition: "50% 3%",
    thumbPosition: "50% 3%",
    role: "Élégance & Sourire Lumineux"
  },
  {
    id: 5,
    name: "Tobi Marek",
    image: LOCAL_IMAGES.childTobi,
    objectPosition: "50% 4%",
    thumbPosition: "50% 4%",
    role: "Énergie & Bonheur Familial"
  }
];

export const FamilyGallerySection: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [activeFamilyPhotoIndex, setActiveFamilyPhotoIndex] = useState(0);
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const autoPlayRef = useRef<NodeJS.Timeout | null>(null);

  // Photos de famille locales
  const familyPhotos = [
    {
      url: LOCAL_IMAGES.family2,
      title: "Les Enfants & La Famille au Grand Complet",
      subtitle: "Mettre à l'honneur les trésors et la joie inestimable de notre famille"
    },
    {
      url: LOCAL_IMAGES.family1,
      title: "Portrait de Famille Réunie",
      subtitle: "Parents et enfants rassemblés dans l'amour et la gratitude"
    }
  ];

  const totalItems = CHILDREN_DATA.length;

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % totalItems);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + totalItems) % totalItems);
  };

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  const [touchStartX, setTouchStartX] = useState<number | null>(null);
  const [touchEndX, setTouchEndX] = useState<number | null>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    setIsPaused(true);
    setTouchStartX(e.targetTouches[0].clientX);
    setTouchEndX(null);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEndX(e.targetTouches[0].clientX);
  };

  const handleTouchEnd = () => {
    setIsPaused(false);
    if (!touchStartX || !touchEndX) return;
    const distance = touchStartX - touchEndX;
    const minSwipeDistance = 45;
    if (distance > minSwipeDistance) {
      // Swiped left -> next
      nextSlide();
    } else if (distance < -minSwipeDistance) {
      // Swiped right -> prev
      prevSlide();
    }
    setTouchStartX(null);
    setTouchEndX(null);
  };

  // Défilement automatique du carrousel des enfants (toutes les 4 secondes si non en pause)
  useEffect(() => {
    if (!isPaused) {
      autoPlayRef.current = setInterval(() => {
        nextSlide();
      }, 4000);
    }
    return () => {
      if (autoPlayRef.current) {
        clearInterval(autoPlayRef.current);
      }
    };
  }, [isPaused, currentIndex]);

  return (
    <section 
      id="galerie-famille" 
      className="relative py-12 sm:py-20 px-3 sm:px-6 bg-[#FFFDF8] text-[#352528] overflow-hidden scroll-mt-16 sm:scroll-mt-20"
    >
      <div className="max-w-5xl mx-auto relative z-10">
        
        {/* En-tête de section exactement selon la demande utilisateur */}
        <div className="text-center max-w-2xl mx-auto mb-8 sm:mb-12 px-2">
          <p className="text-[9px] xs:text-[10px] sm:text-xs tracking-[0.3em] uppercase text-[#C8A45D] font-sans font-semibold mb-2 flex items-center justify-center gap-1.5">
            <Sparkles className="w-3 h-3 text-[#C8A45D]" />
            <span>Notre Héritage &amp; Joie</span>
            <Sparkles className="w-3 h-3 text-[#C8A45D]" />
          </p>

          <h2 className="font-serif-cormorant text-3xl xs:text-4xl sm:text-5xl lg:text-6xl font-light italic text-[#71323A] mb-2 sm:mb-3 leading-tight">
            Notre Héritage &amp; Joie
          </h2>

          <p className="font-serif-cormorant text-sm sm:text-lg text-[#352528]/80 italic max-w-lg mx-auto">
            Mettre à l'honneur les trésors et la joie inestimable de notre famille.
          </p>

          <OrnamentalDivider variant="gold" className="mt-3 sm:mt-4 max-w-xs mx-auto" />
        </div>

        {/* 1. GRANDE PHOTO DEMANDÉE (familly-2.jpg) AVEC CADRAGE PARFAIT OÙ TOUTES LES TÊTES SONT 100% VISIBLES */}
        <div className="mb-12 sm:mb-16 max-w-4xl mx-auto">
          <div className="bg-[#2D161A] rounded-2xl sm:rounded-3xl p-2.5 sm:p-4 border-2 border-[#C8A45D] shadow-2xl overflow-hidden relative">
            
            {/* Conteneur avec ratio optimisé et affichage intégral (object-contain) : 
                Absolument AUCUNE tête ni aucune personne sur les côtés n'est coupée */}
            <div className="relative w-full min-h-[240px] xs:min-h-[300px] sm:min-h-[440px] md:min-h-[500px] max-h-[75vh] rounded-xl sm:rounded-2xl overflow-hidden bg-[#221014] flex items-center justify-center">
              
              {/* Photo demandée avec cadrage complet object-contain garantissant la visibilité totale de tous les visages */}
              <img
                src={familyPhotos[activeFamilyPhotoIndex].url}
                alt={familyPhotos[activeFamilyPhotoIndex].title}
                className="relative z-10 w-full h-auto max-h-[72vh] object-contain mx-auto block rounded-lg sm:rounded-xl shadow-lg"
                loading="lazy"
                decoding="async"
                referrerPolicy="no-referrer"
              />

              {/* Bouton Agrandir / Plein écran */}
              <button
                onClick={() => setIsLightboxOpen(true)}
                className="absolute bottom-3 left-3 z-30 flex items-center gap-1.5 bg-[#2D161A]/90 px-3 py-1.5 rounded-full border border-[#E3C77A]/60 shadow-lg text-[#E3C77A] text-[11px] font-serif-cormorant tracking-wider uppercase hover:bg-[#71323A] transition-colors cursor-pointer min-h-[36px]"
                title="Agrandir la photo en plein écran"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span>Plein Écran</span>
              </button>

              {/* Sélecteur de vue photo de famille */}
              <div className="absolute top-3 right-3 z-30 flex items-center gap-1.5 bg-[#2D161A]/90 px-3 py-1.5 rounded-full border border-[#E3C77A]/60 shadow-lg">
                <Camera className="w-3.5 h-3.5 text-[#E3C77A] mr-1" />
                {familyPhotos.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveFamilyPhotoIndex(idx)}
                    className={`w-4 h-4 rounded-full border border-[#FFFDF8] transition-all cursor-pointer ${
                      activeFamilyPhotoIndex === idx 
                        ? 'bg-[#E3C77A] scale-110 ring-2 ring-[#71323A]' 
                        : 'bg-white/40 hover:bg-white/80'
                    }`}
                    aria-label={`Afficher la photo ${idx + 1} de la famille`}
                  />
                ))}
              </div>
            </div>

            {/* Légende descriptive sous l'image pour ne jamais masquer les visages */}
            <div className="mt-3 px-2 py-1 text-center flex flex-col sm:flex-row items-center justify-between gap-2 text-[#FFFDF8]">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#381B20] text-[#E3C77A] text-[10px] sm:text-xs font-sans font-semibold uppercase tracking-widest border border-[#C8A45D]/50">
                <Users className="w-3.5 h-3.5 text-[#E3C77A]" />
                {familyPhotos[activeFamilyPhotoIndex].title}
              </span>
              <p className="font-serif-cormorant text-xs sm:text-sm text-[#F7F2EA]/90 italic">
                {familyPhotos[activeFamilyPhotoIndex].subtitle}
              </p>
            </div>

          </div>
        </div>

        {/* 2. PORTRAITS INDIVIDUELS DES 5 ENFANTS AVEC CADRAGE PARFAIT SUR CHAQUE VISAGE */}
        <div className="text-center max-w-xl mx-auto mb-6 sm:mb-8 px-2">
          <span className="inline-block text-[10px] sm:text-xs font-sans uppercase tracking-[0.25em] text-[#C8A45D] font-semibold bg-[#F7F2EA] px-4 py-1 rounded-full mb-2">
            Les 5 Trésors de la Famille
          </span>
          <h3 className="font-serif-cormorant text-2xl sm:text-3xl font-semibold text-[#71323A]">
            Portraits Individuels des Enfants
          </h3>
        </div>

        {/* Carrousel Dynamique avec Cadrage Centré Tête Dégagée et Gestes Tactiles Mobile */}
        <div 
          className="relative max-w-2xl mx-auto touch-pan-y"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          {/* Navigation Controls (Précédent / Suivant) */}
          <div className="flex items-center justify-between absolute top-1/2 -translate-y-1/2 -left-3 -right-3 sm:-left-6 sm:-right-6 z-30 pointer-events-none">
            <button
              onClick={prevSlide}
              className="pointer-events-auto p-2.5 sm:p-3.5 rounded-full bg-[#381B20]/90 hover:bg-[#71323A] text-[#E3C77A] border border-[#C8A45D] shadow-xl hover:scale-110 active:scale-95 transition-all cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
              aria-label="Enfant précédent"
            >
              <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
            </button>

            <button
              onClick={nextSlide}
              className="pointer-events-auto p-2.5 sm:p-3.5 rounded-full bg-[#381B20]/90 hover:bg-[#71323A] text-[#E3C77A] border border-[#C8A45D] shadow-xl hover:scale-110 active:scale-95 transition-all cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center"
              aria-label="Enfant suivant"
            >
              <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6" />
            </button>
          </div>

          {/* Slider Viewport */}
          <div className="overflow-hidden px-1 py-2">
            <div 
              className="flex transition-transform duration-500 ease-out"
              style={{
                transform: `translateX(-${currentIndex * 100}%)`,
              }}
            >
              {CHILDREN_DATA.map((child) => {
                return (
                  <div
                    key={child.id}
                    className="w-full shrink-0 px-2 sm:px-4"
                  >
                    <div className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-6 border-2 border-[#C8A45D] shadow-xl text-center flex flex-col items-center justify-between max-w-sm sm:max-w-md mx-auto group">
                      
                      {/* Cadre de photo avec ratio harmonieux et centrage haut sur le visage */}
                      <div className="relative rounded-2xl overflow-hidden aspect-[4/5] w-full mb-4 bg-[#2D161A] border-2 border-[#C8A45D]/60 shadow-md">
                        {/* Portrait net centré depuis le haut pour que la tête et les yeux soient 100% visibles */}
                        <img
                          src={child.image}
                          alt={child.name}
                          className="w-full h-full object-cover"
                          style={{ objectPosition: child.objectPosition }}
                          loading="lazy"
                          decoding="async"
                          referrerPolicy="no-referrer"
                        />
                      </div>

                      {/* Carte Nom & Mention */}
                      <div className="w-full pt-1 flex flex-col items-center">
                        <span className="inline-block text-[10px] sm:text-xs font-sans uppercase tracking-[0.2em] text-[#C8A45D] font-semibold bg-[#F7F2EA] px-3.5 py-1 rounded-full mb-2">
                          {child.role}
                        </span>
                        
                        <h4 className="font-serif-cormorant text-2xl sm:text-3xl font-semibold text-[#71323A] mb-1">
                          {child.name}
                        </h4>
                        
                        <p className="text-xs font-sans text-[#352528]/70 italic mt-1">
                          Fierté, joie et bénédiction partagée
                        </p>
                      </div>

                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Pagination Dots */}
          <div className="flex items-center justify-center gap-2 sm:gap-2.5 mt-4 sm:mt-6">
            {CHILDREN_DATA.map((child, idx) => (
              <button
                key={child.id}
                onClick={() => goToSlide(idx)}
                className="transition-all duration-300 rounded-full cursor-pointer min-h-[36px] min-w-[36px] flex items-center justify-center p-1.5"
                aria-label={`Aller à la photo de ${child.name}`}
              >
                <span className={`block rounded-full transition-all duration-300 ${
                  currentIndex === idx 
                    ? 'w-7 sm:w-8 h-2 sm:h-2.5 bg-[#71323A] border border-[#C8A45D]' 
                    : 'w-2 sm:w-2.5 h-2 sm:h-2.5 bg-[#C8A45D]/40 hover:bg-[#C8A45D]'
                }`} />
              </button>
            ))}
          </div>

          {/* Vignettes Miniatures en bas avec têtes centrées */}
          <div className="grid grid-cols-5 gap-1.5 xs:gap-2 sm:gap-3 mt-5 sm:mt-7 max-w-md mx-auto px-1">
            {CHILDREN_DATA.map((child, idx) => {
              const isSelected = currentIndex === idx;
              return (
                <button
                  key={child.id}
                  onClick={() => goToSlide(idx)}
                  className={`group/thumb flex flex-col items-center text-center cursor-pointer transition-all duration-300 p-1 rounded-xl ${
                    isSelected 
                      ? 'scale-105 opacity-100' 
                      : 'opacity-65 hover:opacity-100 hover:scale-102'
                  }`}
                  aria-label={`Afficher ${child.name}`}
                >
                  <div className={`w-10 h-10 xs:w-11 xs:h-11 sm:w-13 sm:h-13 rounded-full overflow-hidden border-2 transition-all duration-300 bg-[#2D161A] ${
                    isSelected 
                      ? 'border-[#71323A] ring-2 ring-[#E3C77A] shadow-md' 
                      : 'border-[#C8A45D]/50'
                  }`}>
                    <img
                      src={child.image}
                      alt={child.name}
                      className="w-full h-full object-cover"
                      style={{ objectPosition: child.thumbPosition }}
                      loading="lazy"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <span className={`text-[9px] xs:text-[9.5px] sm:text-[10px] font-serif-cormorant font-semibold truncate max-w-full mt-1 ${
                    isSelected ? 'text-[#71323A] font-bold' : 'text-[#352528]/70'
                  }`}>
                    {child.name.split(' ')[0]}
                  </span>
                </button>
              );
            })}
          </div>

        </div>

      </div>

      {/* Lightbox / Modal Plein Écran pour admirer la photo de famille en haute résolution */}
      {isLightboxOpen && (
        <div 
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-3 sm:p-6"
          onClick={() => setIsLightboxOpen(false)}
        >
          <button
            onClick={() => setIsLightboxOpen(false)}
            className="absolute top-4 right-4 p-2.5 rounded-full bg-white/10 text-white hover:bg-white/20 transition-all cursor-pointer z-50 min-h-[44px] min-w-[44px] flex items-center justify-center"
            aria-label="Fermer le plein écran"
          >
            <X className="w-6 h-6" />
          </button>
          
          <div className="relative max-w-5xl max-h-[90vh] flex flex-col items-center justify-center" onClick={(e) => e.stopPropagation()}>
            <img
              src={familyPhotos[activeFamilyPhotoIndex].url}
              alt={familyPhotos[activeFamilyPhotoIndex].title}
              className="w-auto h-auto max-w-full max-h-[82vh] object-contain rounded-xl border border-[#C8A45D] shadow-2xl"
              referrerPolicy="no-referrer"
            />
            <p className="mt-3 text-center text-sm font-serif-cormorant text-[#E3C77A] tracking-wider">
              {familyPhotos[activeFamilyPhotoIndex].title}
            </p>
          </div>
        </div>
      )}
    </section>
  );
};
