import React, { useState } from 'react';
import { Heart, Sparkles } from 'lucide-react';
import { EVENT_DETAILS } from '../data/eventData';
import { OrnamentalDivider } from './OrnamentalDivider';

export const HostsSection: React.FC = () => {
  const [activePapaIndex, setActivePapaIndex] = useState(0);
  const [activeMamanIndex, setActiveMamanIndex] = useState(0);

  const papaImages = [
    EVENT_DETAILS.images.papa,
    EVENT_DETAILS.images.papaSecondary
  ];

  const mamanImages = [
    EVENT_DETAILS.images.maman,
    EVENT_DETAILS.images.mamanSecondary
  ];

  return (
    <section id="hotes" className="relative py-14 sm:py-20 md:py-24 px-3 sm:px-6 bg-[#F7F2EA]/70 text-[#352528] overflow-hidden scroll-mt-16 sm:scroll-mt-20">
      <div className="max-w-5xl mx-auto relative z-10">
        
        {/* En-tête de section */}
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-14 px-2">
          <p className="text-[9px] xs:text-[10px] sm:text-xs tracking-[0.3em] uppercase text-[#C8A45D] font-sans font-semibold mb-2">
            Vos Hôtes d'Honneur
          </p>

          <h2 className="font-serif-cormorant text-2xl xs:text-3xl sm:text-5xl font-normal italic text-[#71323A] mb-2 sm:mb-3 leading-tight">
            Gypsy &amp; Grégoire
          </h2>

          <p className="font-serif-cormorant text-sm sm:text-lg text-[#352528]/75 italic">
            Une union bénie, un jubilé précieux et une vie de famille célébrée avec amour
          </p>

          <OrnamentalDivider variant="gold" className="mt-3 sm:mt-4 max-w-xs mx-auto" />
        </div>

        {/* 1. Grande Photo du Couple */}
        <div className="mb-10 sm:mb-14 max-w-3xl mx-auto">
          <div
            className="block relative rounded-2xl sm:rounded-3xl overflow-hidden border-2 border-[#C8A45D] shadow-xl bg-[#2D161A] group"
          >
            <div className="aspect-[4/3] sm:aspect-[16/11] w-full overflow-hidden relative max-h-[520px]">
              <img
                src={EVENT_DETAILS.images.couple}
                alt="Gypsy & Grégoire - Noces de Porcelaine"
                className="w-full h-full object-cover object-[center_15%] group-hover:scale-102 transition-transform duration-500"
                loading="lazy"
                decoding="async"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#2D161A]/85 via-transparent to-transparent pointer-events-none" />
              
              <div className="absolute bottom-4 left-4 right-4 sm:bottom-6 sm:left-6 sm:right-6 text-[#FFFDF8] flex items-end justify-between gap-2">
                <div>
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#71323A]/90 text-[#E3C77A] text-[10px] sm:text-xs font-sans font-semibold uppercase tracking-widest border border-[#E3C77A]/60 mb-1.5">
                    <Sparkles className="w-3 h-3 text-[#E3C77A]" />
                    Noces de Porcelaine • 20 Ans d'Amour
                  </span>
                  <h3 className="font-serif-cormorant text-xl xs:text-2xl sm:text-4xl font-semibold text-[#FFFDF8] leading-tight">
                    Gypsy &amp; Grégoire
                  </h3>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 2. Portraits Individuels : Maman (Gypsy) & Papa (Grégoire) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 max-w-4xl mx-auto">
          
          {/* Maman - Gypsy (50 Ans) */}
          <div className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-6 border border-[#C8A45D]/60 shadow-lg text-center flex flex-col justify-between">
            <div>
              <div className="relative rounded-2xl overflow-hidden border border-[#C8A45D] mb-4 aspect-[4/5] bg-[#2D161A]">
                <img
                  src={mamanImages[activeMamanIndex]}
                  alt="Maman Gypsy"
                  className="w-full h-full object-cover object-[center_12%] transition-opacity duration-300"
                  loading="lazy"
                  decoding="async"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 right-3 flex gap-1.5 z-10">
                  {mamanImages.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveMamanIndex(idx)}
                      className={`w-2.5 h-2.5 rounded-full border border-[#FFFDF8] transition-all ${
                        activeMamanIndex === idx ? 'bg-[#E3C77A] scale-125' : 'bg-black/40'
                      }`}
                      aria-label={`Photo ${idx + 1} de Maman`}
                    />
                  ))}
                </div>
              </div>

              <span className="inline-block text-[10px] sm:text-xs font-sans uppercase tracking-widest text-[#C8A45D] font-semibold bg-[#F7F2EA] px-3 py-0.5 rounded-full mb-1">
                Jubilé d'Or • 50 Ans
              </span>
              <h3 className="font-serif-cormorant text-2xl sm:text-3xl font-semibold text-[#71323A] mb-1">
                Gypsy
              </h3>
              <p className="text-xs font-sans text-[#352528]/75 leading-relaxed font-light px-2">
                Reine de cette journée, fêtant son demi-siècle de grâce, de beauté et de bienveillance familiale.
              </p>
            </div>
          </div>

          {/* Papa - Grégoire */}
          <div className="bg-white rounded-2xl sm:rounded-3xl p-4 sm:p-6 border border-[#C8A45D]/60 shadow-lg text-center flex flex-col justify-between">
            <div>
              <div className="relative rounded-2xl overflow-hidden border border-[#C8A45D] mb-4 aspect-[4/5] bg-[#2D161A]">
                <img
                  src={papaImages[activePapaIndex]}
                  alt="Papa Grégoire"
                  className="w-full h-full object-cover transition-opacity duration-300"
                  style={{ objectPosition: '50% 10%' }}
                  loading="lazy"
                  decoding="async"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-3 right-3 flex gap-1.5 z-10">
                  {papaImages.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActivePapaIndex(idx)}
                      className={`w-2.5 h-2.5 rounded-full border border-[#FFFDF8] transition-all ${
                        activePapaIndex === idx ? 'bg-[#E3C77A] scale-125' : 'bg-black/40'
                      }`}
                      aria-label={`Photo ${idx + 1} de Papa`}
                    />
                  ))}
                </div>
              </div>

              <span className="inline-block text-[10px] sm:text-xs font-sans uppercase tracking-widest text-[#C8A45D] font-semibold bg-[#F7F2EA] px-3 py-0.5 rounded-full mb-1">
                Pilier du Foyer
              </span>
              <h3 className="font-serif-cormorant text-2xl sm:text-3xl font-semibold text-[#71323A] mb-1">
                Grégoire
              </h3>
              <p className="text-xs font-sans text-[#352528]/75 leading-relaxed font-light px-2">
                Époux dévoué et père protecteur, célébrant deux décennies d'amour et de fidélité.
              </p>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
