import React, { useEffect, useRef, useState } from 'react';

interface FadeInUpSectionProps {
  children: React.ReactNode;
  className?: string;
  id?: string;
  delayMs?: number;
  threshold?: number;
}

export const FadeInUpSection: React.FC<FadeInUpSectionProps> = ({
  children,
  className = '',
  id,
  delayMs = 0,
  threshold = 0.01,
}) => {
  const ref = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    // Respect prefers-reduced-motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) {
      setIsVisible(true);
      return;
    }

    // Pre-trigger smoothly well before entering the viewport (350px ahead) to completely eliminate visual delay
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(element);
        }
      },
      {
        threshold,
        rootMargin: '350px 0px 150px 0px',
      }
    );

    observer.observe(element);

    return () => {
      observer.disconnect();
    };
  }, [threshold]);

  return (
    <div
      ref={ref}
      id={id}
      style={{ transitionDelay: `${delayMs}ms` }}
      className={`fade-in-up-init ${isVisible ? 'fade-in-up-visible' : ''} ${className}`}
    >
      {children}
    </div>
  );
};
