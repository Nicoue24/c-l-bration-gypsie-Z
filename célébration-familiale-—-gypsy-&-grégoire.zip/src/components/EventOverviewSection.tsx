import React from 'react';
import { motion } from 'motion/react';
import { Heart, Star, Users, Calendar, MapPin, Sparkles } from 'lucide-react';
import { EVENT_DETAILS } from '../data/eventData';
import { OrnamentalDivider } from './OrnamentalDivider';
import { CornerFloral, FloralHeaderCrest, SingleRoseAccent } from './RealisticFloralDecor';
import { LOCAL_IMAGES } from '../assets/photos';

export const EventOverviewSection: React.FC = () => {
  return (
    <section id="evenement" className="relative pt-16 pb-12 sm:pt-24 sm:pb-20 px-3 sm:px-6 bg-[#FFFDF8] text-[#352528] overflow-hidden scroll-mt-16 sm:scroll-mt-20" style={{ backgroundImage: 'radial-gradient(circle at 50% 50%, #FFFDF8 0%, #F7F2EA 100%)' }}>
      
      {/* 1 Single Photorealistic Corner Floral Accent - Top Left (Background z-0) */}
      <CornerFloral position="top-left" size="md" className="opacity-35 sm:opacity-50 z-0 pointer-events-none" />

      <div className="max-w-5xl mx-auto relative z-10">
        
        {/* Main Digital Invitation Paper Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="bg-white rounded-2xl sm:rounded-3xl p-4 xs:p-6 sm:p-10 md:p-14 border-[0.5px] border-[#C8A45D] shadow-2xl relative z-20 overflow-hidden text-center"
          style={{ boxShadow: '0 10px 40px rgba(113, 50, 58, 0.06)' }}
        >
          {/* Fine Inner Double Gold Line */}
          <div className="absolute inset-2 sm:inset-4 md:inset-5 rounded-xl sm:rounded-2xl border-[1.5px] border-[#C8A45D]/40 pointer-events-none" />

          {/* Top Label */}
          <p className="text-[9px] xs:text-[10px] sm:text-xs tracking-[0.3em] uppercase text-[#C8A45D] font-sans font-semibold mb-2 sm:mb-3">
            Invitation de Prestige
          </p>

          <h1 className="font-serif-cormorant text-2xl xs:text-3xl sm:text-5xl lg:text-6xl font-normal italic text-[#71323A] leading-tight mb-2 break-words">
            Une Célébration en Famille
          </h1>

          <p className="font-serif-cormorant text-sm sm:text-lg md:text-xl text-[#352528]/80 italic max-w-xl mx-auto mb-4 sm:mb-6 px-2">
            Gypsy &amp; Grégoire ont la joie de vous inviter à célébrer ensemble trois moments d'exception.
          </p>

          <div className="flex items-center justify-center gap-3 my-3 sm:my-4">
            <span className="h-[1px] w-8 sm:w-12 bg-[#C8A45D]" />
            <span className="w-1.5 h-1.5 rounded-full bg-[#C8A45D]" />
            <span className="h-[1px] w-8 sm:w-12 bg-[#C8A45D]" />
          </div>

          {/* 3 Celebrations Grid / Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 lg:gap-8 my-6 sm:my-8 text-center">
            
            {/* 1. Noces de Porcelaine */}
            <div className="relative p-4 sm:p-5 rounded-2xl bg-[#FFFDF8] border-2 border-[#C8A45D] shadow-md flex flex-col justify-between overflow-hidden hover:border-[#71323A] transition-all duration-300 group">
              <div className="relative z-10">
                {/* Photo du Couple Gypsy & Grégoire */}
                <a
                  href="#hotes"
                  className="block rounded-xl overflow-hidden mb-3 border border-[#C8A45D] aspect-[4/5] bg-[#2D161A] shadow-inner relative group/img cursor-pointer"
                  title="Voir la photo du couple Gypsy & Grégoire"
                >
                  <img
                    src={LOCAL_IMAGES.couple}
                    alt="Gypsy & Grégoire - Noces de Porcelaine"
                    className="w-full h-full object-cover object-[center_18%] group-hover/img:scale-103 transition-transform duration-300"
                    loading="lazy"
                    decoding="async"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#2D161A]/80 via-transparent to-transparent opacity-0 group-hover/img:opacity-100 transition-opacity flex items-end justify-center pb-2">
                    <span className="text-[10px] font-sans uppercase tracking-widest text-[#E3C77A] font-semibold">
                      Découvrir
                    </span>
                  </div>
                </a>

                <div className="w-8 h-8 rounded-full bg-[#71323A] text-[#E3C77A] flex items-center justify-center mx-auto mb-2 border border-[#C8A45D] shadow-sm">
                  <Heart className="w-4 h-4 fill-[#E3C77A]" />
                </div>
                <h2 className="font-serif-cormorant text-lg sm:text-xl font-semibold uppercase tracking-wider text-[#71323A] mb-0.5">
                  Noces de Porcelaine
                </h2>
                <span className="text-[11px] sm:text-xs font-sans font-semibold uppercase tracking-wider text-[#9E6E1A] block mb-1.5">
                  ✦ 20 Ans de Grâce • Gypsy &amp; Grégoire ✦
                </span>
                <p className="text-xs font-sans text-[#352528]/70 leading-relaxed font-light">
                  Deux décennies d'amour, de complicité et de bénédictions renouvelées.
                </p>
              </div>
            </div>

            {/* 2. 50 Ans Gypsy */}
            <div className="relative p-4 sm:p-5 rounded-2xl bg-[#F7F2EA]/90 border-2 border-[#C8A45D] shadow-md flex flex-col justify-between overflow-hidden hover:border-[#71323A] transition-all duration-300 group">
              <div className="relative z-10">
                {/* Photo de Maman Gypsy */}
                <a
                  href="#hotes"
                  className="block rounded-xl overflow-hidden mb-3 border border-[#C8A45D] aspect-[4/5] bg-[#2D161A] shadow-inner relative group/img cursor-pointer"
                  title="Voir la photo de Gypsy (50 Ans)"
                >
                  <img
                    src={LOCAL_IMAGES.maman2}
                    alt="Gypsy - Jubilé d'Or 50 Ans"
                    className="w-full h-full object-cover object-[center_12%] group-hover/img:scale-103 transition-transform duration-300"
                    loading="lazy"
                    decoding="async"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#2D161A]/80 via-transparent to-transparent opacity-0 group-hover/img:opacity-100 transition-opacity flex items-end justify-center pb-2">
                    <span className="text-[10px] font-sans uppercase tracking-widest text-[#E3C77A] font-semibold">
                      Découvrir
                    </span>
                  </div>
                </a>

                <div className="w-8 h-8 rounded-full bg-[#71323A] text-[#E3C77A] flex items-center justify-center mx-auto mb-2 border border-[#C8A45D] shadow-sm">
                  <Sparkles className="w-4 h-4 text-[#E3C77A]" />
                </div>
                <h2 className="font-serif-cormorant text-lg sm:text-xl font-semibold uppercase tracking-wider text-[#71323A] mb-0.5">
                  50 Ans de Gypsy
                </h2>
                <span className="text-[11px] sm:text-xs font-sans font-semibold uppercase tracking-wider text-[#C8A45D] block mb-1.5">
                  Jubilé d'Or • 50 Ans de Grâce
                </span>
                <p className="text-xs font-sans text-[#352528]/70 leading-relaxed font-light">
                  Célébration d'un demi-siècle de grâce, de beauté et de bonté.
                </p>
              </div>
            </div>

            {/* 3. Les Enfants : Cadrage Intégral où TOUT LE MONDE et TOUTES LES TÊTES sont visibles */}
            <div className="relative p-4 sm:p-5 rounded-2xl bg-[#FFFDF8] border-2 border-[#C8A45D] shadow-md flex flex-col justify-between overflow-hidden hover:border-[#71323A] transition-all duration-300 group">
              <div className="relative z-10">
                {/* Photo de la Famille & Enfants - Cadrage 100% Intégral sans couper les têtes ni les personnes sur les côtés */}
                <a
                  href="#galerie-famille"
                  className="block rounded-xl overflow-hidden mb-3 border border-[#C8A45D] aspect-[4/5] bg-[#2D161A] shadow-inner relative group/img cursor-pointer"
                  title="Découvrir la Galerie des Enfants"
                >
                  {/* Photo nette avec object-contain : AUCUNE tête coupée, TOUT LE MONDE visible */}
                  <img
                    src={LOCAL_IMAGES.family2}
                    alt="Les Enfants & Famille"
                    className="relative z-10 w-full h-full object-contain p-1 group-hover/img:scale-102 transition-transform duration-300"
                    loading="lazy"
                    decoding="async"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#2D161A]/80 via-transparent to-transparent opacity-0 group-hover/img:opacity-100 transition-opacity flex items-end justify-center pb-2 z-20">
                    <span className="text-[10px] font-sans uppercase tracking-widest text-[#E3C77A] font-semibold">
                      Voir la famille
                    </span>
                  </div>
                </a>

                <div className="w-8 h-8 rounded-full bg-[#71323A] text-[#E3C77A] flex items-center justify-center mx-auto mb-2 border border-[#C8A45D] shadow-sm">
                  <Users className="w-4 h-4" />
                </div>
                <h2 className="font-serif-cormorant text-lg sm:text-xl font-semibold uppercase tracking-wider text-[#71323A] mb-0.5">
                  Notre Héritage &amp; Joie
                </h2>
                <span className="text-[11px] sm:text-xs font-sans font-semibold uppercase tracking-wider text-[#C8A45D] block mb-1.5">
                  Bénédiction &amp; Fierté Familiale
                </span>
                <p className="text-xs font-sans text-[#352528]/70 leading-relaxed font-light">
                  Mettre à l'honneur les trésors et la joie de notre famille.
                </p>
              </div>
            </div>

          </div>

          <OrnamentalDivider variant="gold" className="my-4 sm:my-6 max-w-xs mx-auto" />

          {/* Date, Time, Venue Banner */}
          <div className="bg-gradient-to-r from-[#381B20] via-[#48242A] to-[#381B20] text-[#FFFDF8] p-5 sm:p-7 md:p-8 rounded-2xl border border-[#C8A45D] flex flex-col md:flex-row items-center justify-around gap-4 sm:gap-6 text-center md:text-left shadow-lg font-sans">
            <div className="flex items-center gap-3 w-full md:w-auto justify-center md:justify-start">
              <div className="w-10 h-10 rounded-full bg-[#71323A] border border-[#C8A45D] flex items-center justify-center shrink-0 shadow-sm">
                <Calendar className="w-5 h-5 text-[#E3C77A]" />
              </div>
              <div className="text-left">
                <span className="text-[10px] uppercase tracking-widest text-[#E3C77A] block font-semibold">Date de l'Événement</span>
                <span className="font-serif-cormorant text-base sm:text-lg font-medium">{EVENT_DETAILS.eventDate}</span>
              </div>
            </div>

            <div className="hidden md:block w-px h-10 bg-[#C8A45D]/40" />

            <div className="flex items-center gap-3 w-full md:w-auto justify-center md:justify-start">
              <div className="w-10 h-10 rounded-full bg-[#71323A] border border-[#C8A45D] flex items-center justify-center shrink-0 shadow-sm">
                <MapPin className="w-5 h-5 text-[#E3C77A]" />
              </div>
              <div className="text-left">
                <span className="text-[10px] uppercase tracking-widest text-[#E3C77A] block font-semibold">Lieux des Festivités</span>
                <span className="font-serif-cormorant text-base sm:text-lg font-medium">Messe ({EVENT_DETAILS.churchTime}) &amp; {EVENT_DETAILS.venueName} (18:45)</span>
              </div>
            </div>
          </div>

        </motion.div>

      </div>
    </section>
  );
};
