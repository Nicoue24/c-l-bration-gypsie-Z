import React from 'react';
import { Church, Wine, Navigation, Clock, MapPin, Sparkles, Shirt } from 'lucide-react';
import { EVENT_DETAILS } from '../data/eventData';
import { OrnamentalDivider } from './OrnamentalDivider';

export const VenuesSection: React.FC = () => {
  return (
    <section id="lieux" className="relative py-14 sm:py-20 md:py-24 px-3 sm:px-6 bg-[#F7F2EA]/70 text-[#352528] overflow-hidden border-y border-[#C8A45D]/30 scroll-mt-16 sm:scroll-mt-20">
      
      <div className="max-w-5xl mx-auto relative z-10">
        
        {/* En-tête de Section */}
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-14 px-2">
          <p className="text-[9px] xs:text-[10px] sm:text-xs tracking-[0.3em] uppercase text-[#C8A45D] font-sans font-semibold mb-2 flex items-center justify-center gap-1.5">
            <Sparkles className="w-3 h-3 text-[#C8A45D]" />
            <span>Itinéraire &amp; Lieux de Célébration</span>
            <Sparkles className="w-3 h-3 text-[#C8A45D]" />
          </p>

          <h2 className="font-serif-cormorant text-3xl xs:text-4xl sm:text-5xl font-normal italic text-[#71323A] mb-2 sm:mb-3 leading-tight">
            Les Lieux de la Journée
          </h2>

          <p className="font-serif-cormorant text-sm sm:text-lg text-[#352528]/75 italic">
            La célébration se déroulera en deux temps : la Messe d'Action de Grâces suivie de la Réception.
          </p>

          <OrnamentalDivider variant="gold" className="mt-3 sm:mt-4 max-w-xs mx-auto" />
        </div>

        {/* Grille des Deux Sessions : 1. Messe (D'ABORD) -> 2. Réception (ENSUITE) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 mb-8 sm:mb-12">
          
          {/* SESSION 1 : LA MESSE D'ACTION DE GRÂCES */}
          <div className="relative bg-white rounded-2xl sm:rounded-3xl p-6 sm:p-8 border-2 border-[#C8A45D] shadow-xl flex flex-col justify-between group hover:shadow-2xl transition-all duration-300">
            {/* Tag Étape 1 */}
            <div className="absolute -top-3.5 left-6 bg-[#71323A] text-[#E3C77A] px-3.5 py-1 rounded-full text-[10px] sm:text-xs font-sans font-semibold uppercase tracking-widest border border-[#E3C77A] shadow-md flex items-center gap-1.5">
              <span>1ère Étape</span>
              <span>•</span>
              <span>17:00 précises</span>
            </div>

            <div className="pt-2">
              <div className="w-12 h-12 rounded-2xl bg-[#71323A] text-[#E3C77A] border border-[#C8A45D] flex items-center justify-center mb-4 shadow-sm group-hover:scale-105 transition-transform">
                <Church className="w-6 h-6 text-[#E3C77A]" />
              </div>

              <span className="text-[10px] sm:text-xs font-sans uppercase tracking-[0.2em] text-[#C8A45D] font-semibold block mb-1">
                Célébration Religieuse
              </span>

              <h3 className="font-serif-cormorant text-2xl sm:text-3xl font-semibold text-[#71323A] mb-2 leading-tight">
                Lieu de la Messe
              </h3>

              <div className="space-y-2 mb-4 text-xs sm:text-sm font-sans text-[#352528]/80">
                <div className="flex items-center gap-2 text-[#76363D] font-semibold">
                  <Clock className="w-4 h-4 text-[#C8A45D] shrink-0" />
                  <span>{EVENT_DETAILS.churchTime}</span>
                </div>

                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-[#C8A45D] shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-[#352528] font-serif-cormorant text-base sm:text-lg font-semibold">
                      {EVENT_DETAILS.churchName}
                    </strong>
                    <span className="text-[#352528]/70 text-xs sm:text-sm block font-sans">
                      {EVENT_DETAILS.churchAddress}
                    </span>
                  </div>
                </div>
              </div>

              <p className="text-xs font-sans text-[#352528]/70 leading-relaxed font-light italic mb-6">
                Messe solennelle et prières de bénédiction pour les 20 ans de mariage de Gypsy &amp; Grégoire, le jubilé de Gypsy et les enfants.
              </p>
            </div>

            <a
              href={EVENT_DETAILS.churchMapUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 rounded-full bg-[#71323A] text-[#E3C77A] border border-[#C8A45D] font-sans text-xs sm:text-sm uppercase tracking-wider font-semibold shadow-md hover:bg-[#7A3038] hover:scale-102 active:scale-95 transition-all flex items-center justify-center gap-2 min-h-[44px] cursor-pointer"
            >
              <Navigation className="w-4 h-4 text-[#E3C77A]" />
              <span>Itinéraire vers la Messe</span>
            </a>
          </div>

          {/* SESSION 2 : LE LIEU DE RÉCEPTION */}
          <div className="relative bg-gradient-to-br from-[#381B20] via-[#48242A] to-[#381B20] text-[#FFFDF8] rounded-2xl sm:rounded-3xl p-6 sm:p-8 border-2 border-[#C8A45D] shadow-xl flex flex-col justify-between group hover:shadow-2xl transition-all duration-300">
            {/* Tag Étape 2 */}
            <div className="absolute -top-3.5 left-6 bg-[#C8A45D] text-[#1C0307] px-3.5 py-1 rounded-full text-[10px] sm:text-xs font-sans font-semibold uppercase tracking-widest border border-[#FFFDF8] shadow-md flex items-center gap-1.5">
              <span>2ème Étape</span>
              <span>•</span>
              <span>Dès 18:45</span>
            </div>

            <div className="pt-2">
              <div className="w-12 h-12 rounded-2xl bg-[#71323A] text-[#E3C77A] border border-[#E3C77A]/60 flex items-center justify-center mb-4 shadow-sm group-hover:scale-105 transition-transform">
                <Wine className="w-6 h-6 text-[#E3C77A]" />
              </div>

              <span className="text-[10px] sm:text-xs font-sans uppercase tracking-[0.2em] text-[#E3C77A] font-semibold block mb-1">
                Cocktail, Banquet &amp; Soirée
              </span>

              <h3 className="font-serif-cormorant text-2xl sm:text-3xl font-semibold text-[#FFFDF8] mb-2 leading-tight">
                Lieu de Réception
              </h3>

              <div className="space-y-2.5 mb-4 text-xs sm:text-sm font-sans text-[#F7F2EA]/90">
                <div className="flex items-center gap-2 text-[#E3C77A] font-semibold">
                  <Clock className="w-4 h-4 text-[#E3C77A] shrink-0" />
                  <span>{EVENT_DETAILS.venueTime}</span>
                </div>

                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-[#E3C77A] shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-[#FFEBA8] font-serif-cormorant text-lg sm:text-xl font-semibold">
                      {EVENT_DETAILS.venueName}
                    </strong>
                    <div className="mt-1.5 p-2.5 rounded-xl bg-[#241014]/80 border border-[#C8A45D]/40 text-[#F5EFE4]/90 text-xs leading-relaxed font-sans">
                      <span className="font-semibold text-[#E3C77A] block mb-0.5 uppercase tracking-wider text-[10px]">Indication d'accès :</span>
                      {EVENT_DETAILS.venueAddress}
                    </div>
                  </div>
                </div>
              </div>

              <p className="text-xs font-sans text-[#F7F2EA]/75 leading-relaxed font-light italic mb-6">
                Cocktail de bienvenue, banquet festif, découpe du gâteau d'honneur et célébration dans la joie avec toute la famille.
              </p>
            </div>

            <a
              href={EVENT_DETAILS.venueMapUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 rounded-full bg-gradient-to-r from-[#642931] via-[#76363D] to-[#642931] text-[#E3C77A] border border-[#E3C77A] font-sans text-xs sm:text-sm uppercase tracking-wider font-semibold shadow-md hover:scale-102 active:scale-95 transition-all flex items-center justify-center gap-2 min-h-[44px] cursor-pointer"
            >
              <Navigation className="w-4 h-4 text-[#E3C77A]" />
              <span>Itinéraire vers {EVENT_DETAILS.venueName}</span>
            </a>
          </div>

        </div>

        {/* Note Complémentaire : Dress Code & Accès */}
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-4 sm:p-6 border border-[#C8A45D]/50 text-center max-w-2xl mx-auto shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-left">
            <div className="w-10 h-10 rounded-full bg-[#F7F2EA] text-[#71323A] border border-[#C8A45D]/40 flex items-center justify-center shrink-0">
              <Shirt className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-sans uppercase tracking-widest text-[#76363D] font-bold block">
                Dress Code Conseillé
              </span>
              <p className="text-xs font-serif-cormorant font-semibold text-[#352528]">
                {EVENT_DETAILS.dressCode}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs font-serif-cormorant text-[#71323A]">
            <span className="w-3.5 h-3.5 rounded-full bg-[#FFFFFF] border-2 border-[#C8A45D] shadow-sm shrink-0" />
            <span className="font-bold">Blanc &amp; Chic</span>
            <span className="w-3.5 h-3.5 rounded-full bg-[#C8A45D] border border-[#E3C77A] ml-1 shrink-0" />
            <span>Touches Dorées</span>
          </div>
        </div>

      </div>
    </section>
  );
};
