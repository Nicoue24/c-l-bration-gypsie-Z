import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Users, Church, Clock, ChevronDown, LayoutGrid, List } from 'lucide-react';
import { EventOverviewSection } from './EventOverviewSection';
import { HostsSection } from './HostsSection';
import { FamilyGallerySection } from './FamilyGallerySection';
import { VenuesSection } from './VenuesSection';
import { EventProgram } from './EventProgram';

type TabKey = 'celebrations' | 'family' | 'venues' | 'program';

interface TabItem {
  key: TabKey;
  label: string;
  shortLabel: string;
  icon: React.ElementType;
  badge: string;
}

const TABS: TabItem[] = [
  {
    key: 'celebrations',
    label: 'Les 3 Célébrations',
    shortLabel: 'Célébrations',
    icon: Sparkles,
    badge: '3 en 1'
  },
  {
    key: 'family',
    label: 'Vos Hôtes & Enfants',
    shortLabel: 'Famille',
    icon: Users,
    badge: 'Parents & Enfants'
  },
  {
    key: 'venues',
    label: 'Lieux & Messe',
    shortLabel: 'Lieux',
    icon: Church,
    badge: 'Église & Réception'
  },
  {
    key: 'program',
    label: 'Programme du Jour',
    shortLabel: 'Programme',
    icon: Clock,
    badge: 'Dès 17:00'
  }
];

export const ContentTabsSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabKey>('celebrations');
  const [isExpandedAll, setIsExpandedAll] = useState(false);

  // Écouter les changements de hash dans l'URL pour ouvrir automatiquement le bon onglet
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash === '#evenement') setActiveTab('celebrations');
      else if (hash === '#hotes' || hash === '#galerie-famille') setActiveTab('family');
      else if (hash === '#lieux') setActiveTab('venues');
      else if (hash === '#programme') setActiveTab('program');
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange();
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  return (
    <section className="relative py-8 sm:py-12 bg-[#FFFDF8] text-[#352528] min-h-[600px]">
      <div className="max-w-6xl mx-auto px-3 sm:px-6">
        
        {/* Navigation Selector Bar */}
        <div className="sticky top-14 sm:top-18 z-30 py-3 bg-[#FFFDF8]/95 backdrop-blur-md border-y border-[#C8A45D]/30 shadow-sm mb-6 sm:mb-10">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 max-w-4xl mx-auto">
            
            {/* Tab Pill Buttons */}
            <div className="flex items-center justify-start sm:justify-center gap-1.5 xs:gap-2 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 scrollbar-none px-1">
              {TABS.map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.key && !isExpandedAll;

                return (
                  <button
                    key={tab.key}
                    type="button"
                    onClick={() => {
                      setIsExpandedAll(false);
                      setActiveTab(tab.key);
                    }}
                    className={`shrink-0 inline-flex items-center gap-1.5 sm:gap-2 px-3 xs:px-4 py-2 sm:py-2.5 rounded-full text-xs font-serif-cormorant font-bold uppercase tracking-wider transition-all duration-200 cursor-pointer min-h-[40px] ${
                      isActive
                        ? 'bg-gradient-to-r from-[#71323A] to-[#76363D] text-[#FFFDF8] border border-[#C8A45D] shadow-md scale-102'
                        : 'bg-[#F7F2EA] text-[#71323A] hover:bg-[#EAE0D0] border border-[#C8A45D]/30'
                    }`}
                  >
                    <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#E3C77A]' : 'text-[#76363D]'}`} />
                    <span className="hidden xs:inline">{tab.label}</span>
                    <span className="xs:hidden">{tab.shortLabel}</span>
                  </button>
                );
              })}
            </div>

            {/* Toggle View Mode Button (Compact / Tout afficher) */}
            <button
              type="button"
              onClick={() => setIsExpandedAll(!isExpandedAll)}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-[10px] sm:text-xs font-sans text-[#76363D] hover:text-[#71323A] bg-[#F7F2EA]/60 border border-[#C8A45D]/30 hover:bg-[#F7F2EA] transition-all cursor-pointer whitespace-nowrap self-end sm:self-auto"
              title="Basculer entre la vue par onglets et la vue continue"
            >
              {isExpandedAll ? (
                <>
                  <LayoutGrid className="w-3 h-3 text-[#C8A45D]" />
                  <span>Mode Onglets Rapides</span>
                </>
              ) : (
                <>
                  <List className="w-3 h-3 text-[#C8A45D]" />
                  <span>Tout dérouler</span>
                </>
              )}
            </button>

          </div>
        </div>

        {/* Content Render Area */}
        {isExpandedAll ? (
          /* VUE COMPLÈTE EN CASCADE */
          <div className="space-y-12">
            <div id="evenement">
              <EventOverviewSection />
            </div>
            <div id="hotes">
              <HostsSection />
            </div>
            <div id="galerie-famille">
              <FamilyGallerySection />
            </div>
            <div id="lieux">
              <VenuesSection />
            </div>
            <div id="programme">
              <EventProgram />
            </div>
          </div>
        ) : (
          /* VUE PAR ONGLETS FLUIDES AVEC RÉDUCTION DE SCROLL */
          <div className="relative">
            <AnimatePresence mode="wait">
              {activeTab === 'celebrations' && (
                <motion.div
                  key="celebrations"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.25 }}
                  id="evenement"
                >
                  <EventOverviewSection />
                </motion.div>
              )}

              {activeTab === 'family' && (
                <motion.div
                  key="family"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.25 }}
                  className="space-y-8"
                >
                  <div id="hotes">
                    <HostsSection />
                  </div>
                  <div id="galerie-famille">
                    <FamilyGallerySection />
                  </div>
                </motion.div>
              )}

              {activeTab === 'venues' && (
                <motion.div
                  key="venues"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.25 }}
                  id="lieux"
                >
                  <VenuesSection />
                </motion.div>
              )}

              {activeTab === 'program' && (
                <motion.div
                  key="program"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.25 }}
                  id="programme"
                >
                  <EventProgram />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

      </div>
    </section>
  );
};
