import React, { useState, useEffect } from 'react';
import { InvitationOpening } from './components/InvitationOpening';
import { HeaderNav } from './components/HeaderNav';
import { EventOverviewSection } from './components/EventOverviewSection';
import { HostsSection } from './components/HostsSection';
import { FamilyGallerySection } from './components/FamilyGallerySection';
import { VenuesSection } from './components/VenuesSection';
import { DressCodeSection } from './components/DressCodeSection';
import { CountdownTimer } from './components/CountdownTimer';
import { EventProgram } from './components/EventProgram';
import { RSVPSection } from './components/RSVPSection';
import { Footer } from './components/Footer';
import { BackgroundMusicPlayer } from './components/BackgroundMusicPlayer';
import { FadeInUpSection } from './components/FadeInUpSection';
import { CornerFloral } from './components/RealisticFloralDecor';
import { EVENT_DETAILS } from './data/eventData';

export default function App() {
  const [isEnvelopeOpen, setIsEnvelopeOpen] = useState(true);

  // Force scroll = 0 au chargement initial de l'application
  useEffect(() => {
    // Désactiver la restauration automatique du scroll par le navigateur
    if ('scrollRestoration' in window.history) {
      window.history.scrollRestoration = 'manual';
    }

    // Si un hash accidentel est présent dans l'URL à l'ouverture initiale, le réinitialiser
    if (window.location.hash) {
      window.history.replaceState(null, '', window.location.pathname + window.location.search);
    }

    // Scroll tout en haut au chargement
    window.scrollTo(0, 0);

    const timer = setTimeout(() => {
      window.scrollTo(0, 0);
    }, 50);

    return () => clearTimeout(timer);
  }, []);

  const handleEnvelopeOpened = () => {
    setIsEnvelopeOpen(false);
    // Retour fluide et doux vers le premier écran (Hero)
    window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#FFFDF8] text-[#352528] font-sans relative antialiased selection:bg-[#71323A] selection:text-[#E3C77A] scroll-smooth overflow-x-hidden">
      
      {/* 1. COUVERTURE & OUVERTURE IMMERSIVE: Enveloppe Royale Fermée avec Sceau Rouge */}
      <InvitationOpening
        isOpen={isEnvelopeOpen}
        onOpened={handleEnvelopeOpened}
      />

      {/* Header Bar avec Onglets Fixes */}
      <HeaderNav onReopenInvite={() => setIsEnvelopeOpen(true)} />

      {/* 2. HERO: Premier Écran - Bannière avec Images Directes Familiales */}
      <div id="hero" className="relative pt-20 xs:pt-24 sm:pt-32 pb-12 xs:pb-16 sm:pb-24 px-3 sm:px-6 bg-gradient-to-b from-[#381B20] via-[#48242A] to-[#381B20] text-[#FFFDF8] overflow-hidden text-center border-b-2 border-[#C8A45D]">
        
        {/* Image de fond Hero */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          <img
            src={EVENT_DETAILS.images.heroBackground}
            alt=""
            className="w-full h-full object-cover opacity-20"
            style={{ objectPosition: '50% 10%' }}
            loading="eager"
            decoding="async"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#381B20]/90 via-[#48242A]/85 to-[#381B20]/95" />
        </div>

        {/* 1 Signature Corner Floral Accent */}
        <CornerFloral position="top-left" size="lg" className="opacity-60 sm:opacity-85 z-10" />

        <div className="max-w-4xl mx-auto py-5 xs:py-7 sm:py-10 px-3 xs:px-6 sm:px-10 relative z-20 rounded-2xl sm:rounded-3xl bg-[#3E1E23]/95 border-[0.5px] border-[#C8A45D] shadow-2xl">
          
          {/* Fine Inner Frame Line */}
          <div className="absolute inset-2 xs:inset-2.5 sm:inset-4 rounded-xl sm:rounded-2xl border-[1.5px] border-[#C8A45D]/40 pointer-events-none" />

          {/* 1. Nom / identité de la célébration avec 20 ANS DE GRÂCE bien mis en valeur */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1 sm:px-4 sm:py-1.5 rounded-full bg-[#2A1015]/90 border border-[#E3C77A]/80 shadow-md mb-2 sm:mb-3">
            <span className="text-[#FFE8A3] text-xs">✦</span>
            <span className="text-[10px] xs:text-[11px] sm:text-xs tracking-[0.25em] uppercase text-[#FFEBA8] font-sans font-semibold whitespace-nowrap">
              20 ANS DE GRÂCE • NOCES DE PORCELAINE
            </span>
            <span className="text-[#FFE8A3] text-xs">✦</span>
          </div>

          <h1 className="font-serif-cormorant text-3xl xs:text-4xl sm:text-6xl lg:text-7xl font-normal italic text-[#FFFDF8] tracking-tight mb-2 sm:mb-3 leading-tight break-words">
            Gypsy &amp; Grégoire
          </h1>

          {/* 2. « UNE CÉLÉBRATION COMMUNE RÉUNISSANT TROIS BEAUX ÉVÉNEMENTS » */}
          <h2 className="font-serif-cormorant text-xs xs:text-sm sm:text-xl md:text-2xl font-semibold uppercase tracking-[0.18em] text-[#E3C77A] max-w-2xl mx-auto mb-3 sm:mb-6 px-1 leading-snug">
            Une Célébration Commune Réunissant Trois Beaux Événements
          </h2>

          {/* Image Principale Hero / Faire-part d'Invitation */}
          <div className="my-3 sm:my-6 max-w-lg mx-auto rounded-2xl overflow-hidden border-2 border-[#C8A45D] shadow-xl bg-[#2D161A] relative group p-1 sm:p-2 flex items-center justify-center min-h-[240px] xs:min-h-[300px] sm:min-h-[380px]">
            <img
              src={EVENT_DETAILS.images.heroSecondary}
              alt="Faire-part & Invitation - Gypsy & Grégoire"
              className="w-full h-auto max-h-[68vh] object-contain rounded-xl group-hover:scale-102 transition-transform duration-300 mx-auto block"
              loading="eager"
              decoding="async"
              fetchPriority="high"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* 3. Les éléments d'invitation */}
          <div className="flex items-center justify-center gap-1.5 xs:gap-2 sm:gap-4 my-2.5 sm:my-3 text-[10px] xs:text-[11px] sm:text-xs md:text-sm font-sans tracking-wider uppercase text-[#F5EFE4]/90 flex-wrap">
            <span className="hidden xs:inline-block h-[1px] w-4 sm:w-12 bg-[#C8A45D]" />
            <span>{EVENT_DETAILS.eventDate} • Messe à {EVENT_DETAILS.churchTime} • Réception {EVENT_DETAILS.venueTime}</span>
            <span className="hidden xs:inline-block h-[1px] w-4 sm:w-12 bg-[#C8A45D]" />
          </div>

          <p className="font-serif-cormorant text-xs sm:text-sm md:text-base text-[#F5EFE4]/80 italic mb-3 sm:mb-4">
            {EVENT_DETAILS.churchName} &amp; {EVENT_DETAILS.venueName}
          </p>

          {/* Compteur de jours restant en direct */}
          <CountdownTimer />

          {/* 4. Actions directes */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-2.5 sm:gap-3.5 pt-1 w-full max-w-md mx-auto sm:max-w-none flex-wrap font-sans text-xs sm:text-sm uppercase tracking-wider font-semibold">
            <a
              href="#evenement"
              className="w-full sm:w-auto px-5 sm:px-7 py-3 rounded-full bg-gradient-to-r from-[#642931] via-[#76363D] to-[#642931] text-[#FFEBA8] border border-[#E3C77A] shadow-lg hover:scale-105 active:scale-95 transition-all cursor-pointer min-h-[44px] flex items-center justify-center text-center"
            >
              Découvrir la Célébration
            </a>
            <a
              href="#rsvp"
              className="w-full sm:w-auto px-5 sm:px-7 py-3 rounded-full bg-[#32171B]/90 text-[#FFFDF8] border border-[#C8A45D]/80 hover:border-[#E3C77A] hover:text-[#FFE8A3] hover:scale-105 active:scale-95 transition-all cursor-pointer min-h-[44px] flex items-center justify-center text-center shadow-md"
            >
              Confirmer Ma Présence
            </a>
            <a
              href="#dress-code"
              className="w-full sm:w-auto px-5 sm:px-7 py-3 rounded-full bg-[#FAF7F0] text-[#420D15] border border-[#C8A45D] hover:bg-[#FFFFFF] hover:scale-105 active:scale-95 transition-all cursor-pointer min-h-[44px] flex items-center justify-center text-center shadow-md"
            >
              Dress Code : Blanc &amp; Chic
            </a>
            <a
              href="#lieux"
              className="w-full sm:w-auto px-5 sm:px-7 py-3 rounded-full bg-[#241014]/85 text-[#F5EFE4] border border-[#C8A45D]/60 hover:border-[#E3C77A] hover:text-[#FFE8A3] hover:scale-105 active:scale-95 transition-all cursor-pointer min-h-[44px] flex items-center justify-center text-center shadow-md"
            >
              Lieux des Célébrations
            </a>
          </div>
        </div>
      </div>

      {/* 3. CONFIRMER SA PRÉSENCE (RSVP) */}
      <FadeInUpSection id="rsvp-wrapper">
        <RSVPSection />
      </FadeInUpSection>

      {/* 4. LES 3 CÉLÉBRATIONS (AU COEUR DE L'ÉVÉNEMENT) */}
      <FadeInUpSection id="evenement-wrapper">
        <EventOverviewSection />
      </FadeInUpSection>

      {/* 5. CODE VESTIMENTAIRE : DRESS CODE BLANC & CHIC */}
      <FadeInUpSection id="dress-code-wrapper">
        <DressCodeSection />
      </FadeInUpSection>

      {/* 6. VOS HÔTES D'HONNEUR (GYPSY & GRÉGOIRE) */}
      <FadeInUpSection id="hotes-wrapper">
        <HostsSection />
      </FadeInUpSection>

      {/* 7. LES ENFANTS (TRÉSORS DE LA FAMILLE & GRANDE PHOTO DE GROUPE) */}
      <FadeInUpSection id="galerie-famille-wrapper">
        <FamilyGallerySection />
      </FadeInUpSection>

      {/* 8. LIEUX DU JOUR : LA MESSE PUIS LE CHÂTEAU */}
      <FadeInUpSection id="lieux-wrapper">
        <VenuesSection />
      </FadeInUpSection>

      {/* 9. PROGRAMME DÉTAILLÉ DU JOUR */}
      <FadeInUpSection id="programme-wrapper">
        <EventProgram />
      </FadeInUpSection>

      {/* 9. FOOTER */}
      <Footer />

      {/* 10. LECTEUR DE MUSIQUE D'ADORATION FLOTTANT (CONTRÔLE LECTURE / PAUSE) */}
      <BackgroundMusicPlayer autoPlayTrigger={!isEnvelopeOpen} />
    </div>
  );
}
